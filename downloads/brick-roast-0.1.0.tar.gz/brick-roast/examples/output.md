# Website Roast — TabTamer

URL: https://example.com/tabtamer  
Audience: remote workers drowning in browser tabs  
Primary goal: install the browser extension

## TL;DR

- Overall impression: TODO
- Biggest leak: TODO
- Fastest win: TODO
- Would I trust/buy/sign up? TODO

## Raw notes

The product organizes tabs with AI. The landing page says 'AI-powered workspace clustering' but does not address privacy, Chrome tab groups, or show a demo.

## Scorecard

| Area | Score | Notes |
|---|---:|---|
| Clarity | TODO/10 | TODO |
| Trust | TODO/10 | TODO |
| Conversion path | TODO/10 | TODO |
| Copy | TODO/10 | TODO |
| Visual hierarchy | TODO/10 | TODO |
| Mobile readiness | TODO/10 | TODO |
| SEO basics | TODO/10 | TODO |

## First 10-second read

What I understand immediately:

- TODO

What confuses me:

- TODO

What I want to click next:

- TODO

## Conversion blockers

1. TODO
2. TODO
3. TODO

## Trust gaps

1. TODO
2. TODO
3. TODO

## Copy fixes

- Current: TODO
- Better: TODO
- Why: TODO

## Top 5 fixes

1. TODO
2. TODO
3. TODO
4. TODO
5. TODO

## Optional next step

TODO

