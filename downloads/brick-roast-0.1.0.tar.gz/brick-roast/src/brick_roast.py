#!/usr/bin/env python3
"""Generate a structured website roast report from a small JSON brief.

This is a lightweight scaffolding tool: it does not fetch websites or call AI APIs.
It turns messy notes into a consistent report that a human/agent can complete.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


def load_brief(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    required = ["site_name", "url", "audience", "goal", "notes"]
    missing = [k for k in required if not str(data.get(k, "")).strip()]
    if missing:
        raise SystemExit(f"Missing required fields: {', '.join(missing)}")
    return data


def render(data: dict) -> str:
    site = data["site_name"]
    url = data["url"]
    audience = data["audience"]
    goal = data["goal"]
    notes = data["notes"]
    return f"""# Website Roast — {site}

URL: {url}  
Audience: {audience}  
Primary goal: {goal}

## TL;DR

- Overall impression: TODO
- Biggest leak: TODO
- Fastest win: TODO
- Would I trust/buy/sign up? TODO

## Raw notes

{notes}

## Scorecard

| Area | Score | Notes |
|---|---:|---|
| Clarity | TODO/10 | TODO |
| Trust | TODO/10 | TODO |
| Conversion path | TODO/10 | TODO |
| Copy | TODO/10 | TODO |
| Visual hierarchy | TODO/10 | TODO |
| Mobile readiness | TODO/10 | TODO |
| SEO basics | TODO/10 | TODO |

## First 10-second read

What I understand immediately:

- TODO

What confuses me:

- TODO

What I want to click next:

- TODO

## Conversion blockers

1. TODO
2. TODO
3. TODO

## Trust gaps

1. TODO
2. TODO
3. TODO

## Copy fixes

- Current: TODO
- Better: TODO
- Why: TODO

## Top 5 fixes

1. TODO
2. TODO
3. TODO
4. TODO
5. TODO

## Optional next step

TODO
"""


def main(argv: list[str]) -> int:
    if len(argv) != 2 or argv[1] in {"-h", "--help"}:
        print("Usage: brick_roast.py brief.json", file=sys.stderr)
        return 2
    path = Path(argv[1])
    print(render(load_brief(str(path))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
