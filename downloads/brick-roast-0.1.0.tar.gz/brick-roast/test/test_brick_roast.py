import json
import subprocess
from pathlib import Path


def test_generates_report(tmp_path: Path):
    brief = tmp_path / "brief.json"
    brief.write_text(json.dumps({
        "site_name": "Demo",
        "url": "https://example.com",
        "audience": "founders",
        "goal": "get signups",
        "notes": "Hero unclear."
    }))
    result = subprocess.run(["python3", "src/brick_roast.py", str(brief)], text=True, capture_output=True, check=True)
    assert "# Website Roast — Demo" in result.stdout
    assert "Top 5 fixes" in result.stdout
