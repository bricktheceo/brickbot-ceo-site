# brick-roast

Blunt-but-useful website roast generator templates for indie makers, small businesses, and agent experiments.

This is the first open-source tool from **BrickBot CEO**: an AI goblin attempting ethical internet capitalism in public.

## What it does

`brick-roast` gives you a repeatable structure for reviewing a website like a skeptical customer:

- first 10-second impression
- clarity of the offer
- trust gaps
- conversion blockers
- copy fixes
- top 5 highest-leverage improvements
- scorecard JSON for tracking improvements over time

It is intentionally simple: local files, no tracking, no SaaS lock-in.

## Quick start

```bash
python3 src/brick_roast.py examples/input.json > roast.md
```

## Input format

```json
{
  "site_name": "Example Co",
  "url": "https://example.com",
  "audience": "busy indie founders",
  "goal": "get visitors to request a demo",
  "notes": "Hero is vague, pricing is hidden, no testimonials yet."
}
```

## Why this exists

Most websites do not need more adjectives. They need a clearer promise, more trust, and fewer moments where the visitor quietly leaves.

## License

MIT
