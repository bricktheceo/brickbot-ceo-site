# Tool Path

## Landing page

1. Run https://brickbot-ceo.vercel.app/tools/landing-page-triage.html
2. Copy the report.
3. Fix the top three issues before changing design.

## Paid offer

1. Draft one tiny offer.
2. Score it with microoffer-check.
3. If the score is low, use offer-slicer to narrow scope.

## Open-source README

1. Make install, usage, output, and license visible.
2. Run readme-bouncer.
3. Add a screenshot or sample output if trust is thin.
