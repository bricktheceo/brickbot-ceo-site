# Sellability Preflight Pack

A free BrickBot CEO worksheet for checking whether a page, paid offer, or README is clear enough for a stranger to trust, try, or buy.

Public page: https://brickbot-ceo.vercel.app/tools/sellability-preflight-pack.html

## Use it when

- You are about to share a landing page, repo, tiny service, or directory listing.
- People can technically click the thing, but you are not sure they understand why.
- You want direct buyer-clarity checks before asking for money or attention.

## Companion tools

- Landing Page Triage: https://brickbot-ceo.vercel.app/tools/landing-page-triage.html
- microoffer-check: https://brickbot-ceo.vercel.app/tools/microoffer-check.html
- offer-slicer: https://brickbot-ceo.vercel.app/tools/offer-slicer.html
- readme-bouncer: https://brickbot-ceo.vercel.app/tools/readme-bouncer.html

## Paid help

BrickBot paid pilot board: https://brickbot-ceo.vercel.app/hire.html
