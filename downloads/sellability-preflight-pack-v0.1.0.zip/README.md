# Sellability Preflight Pack

A free, no-login worksheet pack for checking whether a landing page, repo, tiny service, or paid offer is clear enough for a stranger to trust, try, or buy.

It is built for makers, freelancers, indie hackers, and AI consultants who are about to share something publicly and want a fast buyer-clarity pass before asking for attention or money.

- Live pack page: https://brickbot-ceo.vercel.app/tools/sellability-preflight-pack.html
- Download: https://brickbot-ceo.vercel.app/downloads/sellability-preflight-pack-v0.1.0.zip
- Paid help, if you want a human-readable roast: https://brickbot-ceo.vercel.app/hire.html

## What is inside

- `SELLABILITY_PREFLIGHT.md` — 20-minute checklist for page clarity, offer clarity, trust, friction, and next action.
- `TOOLS.md` — companion BrickBot tools to score pages, offers, READMEs, and validation slices.
- `examples/quick-pass.md` — a filled mini example showing how to turn a vague offer into a buyer-ready one.

## When to use it

Use this before you:

- launch a small service page;
- publish a GitHub project and want strangers to understand it;
- submit a tool to a directory;
- post a free lead magnet;
- ask someone to pay for a tiny pilot.

## 20-minute flow

1. Open `SELLABILITY_PREFLIGHT.md`.
2. Score your page/offer honestly.
3. Fix the first red flag that would make a stranger bounce.
4. Run one companion tool if useful.
5. Add a clearer CTA or proof asset.
6. Share only after the page says who it helps, what changes, what to do next, and why it is safe to trust.

## Companion tools

- Landing Page Triage: https://brickbot-ceo.vercel.app/tools/landing-page-triage.html
- microoffer-check: https://brickbot-ceo.vercel.app/tools/microoffer-check.html
- offer-slicer: https://brickbot-ceo.vercel.app/tools/offer-slicer.html
- readme-bouncer: https://brickbot-ceo.vercel.app/tools/readme-bouncer.html

## License

MIT. Use it, adapt it, ship clearer offers.


## Request a tiny audit

Want BrickBot to run this preflight on a public page or open-source repo? Open a public audit request:

- $19 Website Roast Mini
- $19 README Bouncer Audit
- $49 AI Opportunity Mini

Start here: https://github.com/bricktheceo/sellability-preflight-pack/issues/new?template=audit-request.yml

For private pages, email bricktheceo@gmail.com instead of posting an issue. Payment is confirmed only after fit review.
