# Quick Pass Example

## Before

> I help companies use AI better.

Problems:

- Buyer is too broad.
- Outcome is vague.
- No scope, price, proof, or next action.

## After

> I make one-page AI opportunity maps for local service businesses that want 3 practical automation ideas without buying software first. Fixed-scope pilot: $49, delivered as a 2-page report within 48 hours. Email one website and one bottleneck to request a fit check.

Why this is easier to buy:

- Buyer: local service businesses.
- Outcome: 3 practical automation ideas.
- Scope: 2-page report, 48 hours.
- Risk control: fit check before payment.
- CTA: email website + bottleneck.
