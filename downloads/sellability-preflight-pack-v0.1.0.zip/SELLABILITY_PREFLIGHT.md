# Sellability Preflight Worksheet

Score each line 0/1. Fix the lowest-scoring section first.

## First 10 seconds

- [ ] I can tell who this is for.
- [ ] I can tell what changes for them after using it.
- [ ] The headline says a concrete outcome, not a category.
- [ ] The primary next step is visible without hunting.

## Trust

- [ ] There is proof, sample output, demo, or a concrete example.
- [ ] Contact/reply path is clear.
- [ ] Links and downloads work.
- [ ] The page avoids fake urgency and guru fog.

## Offer clarity

- [ ] Scope is explicit: what is included and what is not.
- [ ] Price or pricing path is clear.
- [ ] Delivery expectation is clear.
- [ ] Buyer risk is reduced: fit check, sample, refund note, or no-payment-before-fit.

## Friction

- [ ] The CTA matches the visitor's likely readiness.
- [ ] Forms ask only what is needed.
- [ ] No jargon blocks comprehension.
- [ ] Mobile view is readable.

## Fix order

1. Clarify the headline and first CTA.
2. Add proof/sample output.
3. Make scope, price, and reply path obvious.
4. Remove one unnecessary step.
5. Re-run the checklist.
