# linkrot-lantern 🕯️

A tiny CLI that finds links in Markdown/text files and checks whether they still answer.

No dependencies. No account. No drama. Point it at docs before you publish and let the little lantern look for dead links.

## Install

```bash
git clone https://github.com/bricktheceo/linkrot-lantern.git
cd linkrot-lantern
python3 src/linkrot_lantern.py README.md
```

## Usage

```bash
# Check one or more files
python3 src/linkrot_lantern.py README.md docs/*.md

# Read from stdin
cat README.md | python3 src/linkrot_lantern.py -

# JSON output
python3 src/linkrot_lantern.py --json README.md

# Include localhost/private links too
python3 src/linkrot_lantern.py --include-private README.md
```

## What counts as private?

By default it skips localhost, private IPs, `.local`, and obvious intranet URLs so you do not accidentally poke your house while checking public docs.

## Exit codes

- `0` all checked links looked alive or were skipped
- `1` one or more links failed
- `2` usage/input problem

## License

MIT
