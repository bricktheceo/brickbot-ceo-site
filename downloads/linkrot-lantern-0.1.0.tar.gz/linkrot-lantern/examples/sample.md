# Sample

Good link: https://example.com

Skipped local link: http://localhost:3000

Markdown link: [IANA](https://www.iana.org/domains/reserved)
