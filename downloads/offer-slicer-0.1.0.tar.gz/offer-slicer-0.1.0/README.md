# offer-slicer

Turn a broad business/tool/service idea into a tiny validation slice you can ship, price, and kill/keep quickly.

This is for builders who keep making giant vague offers like “AI automation for local businesses.” `offer-slicer` forces the idea into:

- one narrow buyer
- one painful moment
- one 48-hour promise
- a strict scope fence
- proof to publish before outreach
- a simple price test
- a kill/keep metric

No dependencies. No network. No accounts. Just a small Python CLI.

## Quick start

```bash
python3 offer_slicer.py "AI automation audits for local HVAC companies" --buyer "owner-operated HVAC shops with slow lead follow-up" --price 99
```

## Example output

See [`examples/hvac-ai-audit.md`](examples/hvac-ai-audit.md).

## Why this exists

Most first offers fail because they are too broad to buy and too large to deliver. A good first-money artifact should be small enough to complete this week and concrete enough that a stranger can say yes or no.

## License

MIT
