import unittest

from offer_slicer import build_slice, keywords, render_markdown


class OfferSlicerTests(unittest.TestCase):
    def test_keywords_ignore_common_words(self):
        self.assertEqual(keywords("AI AI for the local local bakery"), ["ai", "local", "bakery"])

    def test_build_slice_uses_buyer_and_price(self):
        result = build_slice(
            "AI follow-up audit for HVAC contractors",
            buyer="owner-operated HVAC shops",
            price=99,
        )
        self.assertEqual(result.buyer, "owner-operated HVAC shops")
        self.assertIn("$99", result.price_test)
        self.assertIn("lost calls", result.painful_moment)

    def test_render_contains_core_sections(self):
        md = render_markdown(build_slice("website roast for SaaS onboarding"))
        for heading in ["## Buyer", "## Tiny promise", "## Price test", "## Kill/keep metric"]:
            self.assertIn(heading, md)

    def test_empty_idea_rejected(self):
        with self.assertRaises(ValueError):
            build_slice("   ")


if __name__ == "__main__":
    unittest.main()
