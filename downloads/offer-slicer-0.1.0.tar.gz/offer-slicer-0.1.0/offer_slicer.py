#!/usr/bin/env python3
"""Offer Slicer: turn a broad service idea into a tiny sellable validation slice.

No network, no dependencies, no private data collection. Feed it a rough offer and it
returns a one-page action plan you can test manually.
"""
from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from datetime import date


STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "i", "in",
    "into", "is", "it", "of", "on", "or", "our", "that", "the", "their", "this",
    "to", "with", "you", "your", "we", "will", "help", "helps", "using", "use",
}

PAIN_PATTERNS = [
    (r"\b(local|small|solo|independent)\b", "time-starved operators who need obvious ROI"),
    (r"\b(restaurant|cafe|bar|bakery|food)\b", "missed bookings, weak menu clarity, and review anxiety"),
    (r"\b(plumber|roofer|hvac|electrician|contractor|home service)\b", "lost calls, slow quote follow-up, and low-trust pages"),
    (r"\b(sa[a]s|software|app|startup)\b", "unclear positioning and trial friction"),
    (r"\b(ai|automation|chatbot|agent)\b", "AI curiosity without a concrete workflow or measurable win"),
    (r"\b(newsletter|creator|course|coach)\b", "audience trust, conversion copy, and proof gaps"),
]

@dataclass(frozen=True)
class Slice:
    title: str
    buyer: str
    painful_moment: str
    promise: str
    tiny_scope: list[str]
    proof: list[str]
    price_test: str
    outreach: str
    success_metric: str


def keywords(text: str, limit: int = 6) -> list[str]:
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9'-]{1,}", text.lower())
    counts: dict[str, int] = {}
    for word in words:
        if word not in STOPWORDS:
            counts[word] = counts.get(word, 0) + 1
    return [w for w, _ in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:limit]]


def infer_pain(text: str) -> str:
    lower = text.lower()
    matches = [pain for pattern, pain in PAIN_PATTERNS if re.search(pattern, lower)]
    return matches[0] if matches else "a fuzzy problem that needs a clearer before/after"


def title_from(text: str) -> str:
    kws = keywords(text, 4)
    if not kws:
        return "Tiny Offer Validation Slice"
    return " ".join(word.capitalize() for word in kws[:4]) + " Sprint"


def build_slice(idea: str, buyer: str | None = None, price: int | None = None) -> Slice:
    clean = " ".join(idea.strip().split())
    if not clean:
        raise ValueError("Provide a rough offer idea.")
    kws = keywords(clean)
    inferred_buyer = buyer or ("people searching for " + ", ".join(kws[:3]) if kws else "one narrow buyer group")
    pain = infer_pain(clean)
    price_text = f"Offer 3 beta slots at ${price}" if price else "Offer 3 beta slots at $49, $99, and $149; keep the first price that gets a yes without a long explanation"
    top_keyword = kws[0] if kws else "result"
    return Slice(
        title=title_from(clean),
        buyer=inferred_buyer,
        painful_moment=pain,
        promise=f"In 48 hours, deliver one concrete {top_keyword} improvement the buyer can inspect, not a strategy cloud.",
        tiny_scope=[
            "Audit one URL, workflow, or asset only",
            "Return a one-page before/after report",
            "Include exactly 5 prioritized fixes",
            "Add one copy/paste script, checklist, or template the buyer can use immediately",
        ],
        proof=[
            "Make a fictional sample using a clearly labeled demo company",
            "Publish the blank template so buyers see the deliverable shape",
            "Track: sent, opened/replied, call booked, paid, delivered",
        ],
        price_test=price_text,
        outreach=f"Ask 10 narrowly matched prospects: 'Want me to make a 5-fix {top_keyword} teardown for your {top_keyword} page/workflow? Free sample if I can publish the anonymized before/after.'",
        success_metric="A winning slice gets 2+ replies or 1 paid beta from 10 targeted asks. If not, narrow the buyer or pain and retry.",
    )


def render_markdown(slice_: Slice) -> str:
    bullets = lambda xs: "\n".join(f"- {x}" for x in xs)
    return "\n\n".join([
        f"# {slice_.title}",
        f"Generated: {date.today().isoformat()}",
        "## Buyer\n" + slice_.buyer,
        "## Painful moment\n" + slice_.painful_moment,
        "## Tiny promise\n" + slice_.promise,
        "## Scope fence\n" + bullets(slice_.tiny_scope),
        "## Proof to ship before outreach\n" + bullets(slice_.proof),
        "## Price test\n" + slice_.price_test,
        "## Outreach line\n> " + slice_.outreach,
        "## Kill/keep metric\n" + slice_.success_metric,
    ]) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Turn a broad idea into a tiny sellable validation slice.")
    parser.add_argument("idea", help="Rough business/tool/service idea in quotes")
    parser.add_argument("--buyer", help="Optional narrow buyer description")
    parser.add_argument("--price", type=int, help="Optional beta price to test")
    args = parser.parse_args(argv)
    print(render_markdown(build_slice(args.idea, args.buyer, args.price)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
