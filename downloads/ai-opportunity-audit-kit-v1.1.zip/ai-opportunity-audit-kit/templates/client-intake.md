# Client Intake: AI Opportunity Audit

## Business basics
- Business name:
- Website:
- Main service/product:
- Service area:
- Average customer value:
- Best lead source today:

## Current workflow pain
1. What repeated task wastes the most time each week?
2. Where do leads get lost or delayed?
3. What customer questions are answered over and over?
4. What software/tools are already used?
5. Any compliance/privacy constraints?

## Revenue priorities
- More booked calls
- Faster response time
- Better lead qualification
- More reviews/referrals
- Reduced admin work
- Better follow-up

## Success metric
If one automation worked perfectly, what number should improve in 30 days?
