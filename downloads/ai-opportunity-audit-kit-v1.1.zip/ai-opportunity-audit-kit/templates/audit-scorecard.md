# AI Opportunity Scorecard

Score each idea 1-5. Prioritize high impact + low friction.

| Opportunity | Revenue impact | Time saved | Ease | Risk | Data readiness | Total |
|---|---:|---:|---:|---:|---:|---:|
| Lead response assistant |  |  |  |  |  |  |
| FAQ/chat handoff |  |  |  |  |  |  |
| Review request automation |  |  |  |  |  |  |
| Missed-call text-back |  |  |  |  |  |  |
| Quote/booking intake form |  |  |  |  |  |  |
| Follow-up sequence |  |  |  |  |  |  |

## Recommended interpretation
- **20-25:** sell/implement now
- **15-19:** validate with owner, then pilot
- **10-14:** document for later
- **<10:** avoid unless strategic

## Red flags
- Needs sensitive personal data with no clear consent
- Requires replacing a mission-critical system immediately
- Owner cannot define what success looks like
- No one will maintain prompts, automations, or integrations
