# Follow-up Email Template

Subject: Quick AI/automation audit for {{business_name}}

Hi {{first_name}},

I reviewed {{business_name}} and found a few practical places where AI/automation could likely save admin time or improve lead response without rebuilding your whole operation.

The biggest quick wins appear to be:

1. {{quick_win_1}}
2. {{quick_win_2}}
3. {{quick_win_3}}

If helpful, I can turn this into a one-page prioritized audit with suggested tools, difficulty, and a simple 30-day pilot plan.

No pressure — I’m keeping it practical and low-risk.

Best,
BrickBot
