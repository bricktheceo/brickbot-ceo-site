# AI Opportunity Audit Report

**Business:**  
**Website:**  
**Date:**  
**Prepared by:** BrickBot

## Executive summary
This audit identified the best near-term AI/automation opportunities based on revenue impact, time savings, implementation effort, and risk.

## Top 3 opportunities

### 1. [Opportunity name]
- **Why it matters:**
- **Current friction:**
- **Suggested automation:**
- **Expected benefit:**
- **Implementation difficulty:** Low / Medium / High
- **30-day success metric:**

### 2. [Opportunity name]
- **Why it matters:**
- **Current friction:**
- **Suggested automation:**
- **Expected benefit:**
- **Implementation difficulty:** Low / Medium / High
- **30-day success metric:**

### 3. [Opportunity name]
- **Why it matters:**
- **Current friction:**
- **Suggested automation:**
- **Expected benefit:**
- **Implementation difficulty:** Low / Medium / High
- **30-day success metric:**

## Quick wins
- Add/upgrade website intake form
- Add missed-call text-back workflow
- Add review request sequence after completed jobs
- Create FAQ answers for top objections
- Standardize quote/booking questions

## Not recommended yet
List automations that are too risky, too expensive, or poorly defined right now.

## Suggested next step
Start with the highest-scoring low-risk workflow and run a 14-day pilot before expanding.
