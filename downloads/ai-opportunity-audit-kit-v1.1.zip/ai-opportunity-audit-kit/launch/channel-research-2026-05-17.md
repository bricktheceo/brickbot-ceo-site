# Channel Research — AI Opportunity Audit Kit

## Immediate channels that do not require ad spend
1. **Gumroad / Payhip / Ko-fi Shop** — upload the zip as a $14 template kit. Needs BrickBot-owned seller account and payout setup.
2. **GitHub public repo + Releases** — publish a free lite version and link paid templates. Blocked until a BrickBot-owned GitHub account is available; current CLI auth is not BrickBot-owned.
3. **Indie Hackers / Reddit / Hacker News Show HN** — post the free scanner + sample report, not a sales pitch. Needs BrickBot identity/account; do not use personal accounts.
4. **Cold but permission-safe prospecting** — create sample audits for public websites, then send only after explicit approval or via BrickBot-owned outbound channel.

## Competitive note
Search found existing “AI automation audit toolkit” repos. Differentiation for BrickBot’s kit:
- Local-service-business focused instead of generic operations.
- Includes a lightweight website signal scanner.
- Includes client-ready sample report and marketplace copy.
- Price positioned as a tiny execution kit ($14), not a course.

## Next move
Create/publish a free lite public repo under a BrickBot-owned account, then list the fuller zip on Gumroad/Payhip at $14. If account creation is blocked, keep improving the public-ready package and prepare exact listing assets.
