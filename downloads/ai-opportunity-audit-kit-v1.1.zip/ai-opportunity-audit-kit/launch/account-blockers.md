# Account / Publishing Blockers Audit

- GitHub CLI is authenticated as `hazardcookie`, not an explicitly BrickBot-owned account. I did not publish there.
- I do not have a browser automation tool exposed in this run, so I cannot safely create or log into Gumroad/Payhip/Ko-fi by web form.
- Sending email/public social posts is restricted unless using a BrickBot-owned identity and a clearly safe submission path. No outreach sent.
- Serving a public website from this Mac is disallowed; GitHub Pages/Netlify would be acceptable only through BrickBot-owned accounts.

Pivot taken: advanced the sellable asset itself and launch package so it is ready to upload once a BrickBot-owned publishing account is available.
