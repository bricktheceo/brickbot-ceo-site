#!/usr/bin/env python3
"""Lightweight website signal scanner for AI opportunity audits.

Usage:
  python3 scripts/site_signal_scanner.py https://example.com

It intentionally does not crawl aggressively: one page fetch, simple text heuristics.
"""
import re
import sys
import urllib.request
from html.parser import HTMLParser
from urllib.parse import urlparse

SIGNALS = {
    "booking/scheduling": ["book", "schedule", "appointment", "calendar", "consultation"],
    "lead capture": ["contact", "quote", "estimate", "form", "call", "email"],
    "faq/support": ["faq", "questions", "help", "support", "how it works"],
    "reviews/social proof": ["review", "testimonial", "stars", "google rating", "trusted"],
    "pricing/qualification": ["pricing", "price", "packages", "plans", "financing"],
    "urgency/local service": ["emergency", "same day", "24/7", "near me", "local"],
}

IDEAS = {
    "booking/scheduling": "Booking assistant or appointment reminder workflow",
    "lead capture": "Lead qualification + instant response sequence",
    "faq/support": "FAQ chatbot with human handoff",
    "reviews/social proof": "Automated post-service review request",
    "pricing/qualification": "Quote/intake form that routes leads by fit and urgency",
    "urgency/local service": "Missed-call text-back and urgent lead triage",
}

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = False
    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript"}:
            self.skip = True
    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript"}:
            self.skip = False
    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def fetch(url):
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    req = urllib.request.Request(url, headers={"User-Agent": "BrickBotAuditKit/1.0"})
    with urllib.request.urlopen(req, timeout=12) as resp:
        return resp.read(800_000).decode("utf-8", errors="replace"), resp.geturl()


def main():
    if len(sys.argv) != 2:
        print("Usage: site_signal_scanner.py https://example.com", file=sys.stderr)
        return 2
    html, final_url = fetch(sys.argv[1])
    parser = TextExtractor()
    parser.feed(html)
    text = re.sub(r"\s+", " ", " ".join(parser.parts)).lower()

    print(f"AI Opportunity Signal Scan")
    print(f"URL: {final_url}")
    print(f"Domain: {urlparse(final_url).netloc}\n")

    found = []
    for category, terms in SIGNALS.items():
        hits = sorted({term for term in terms if term in text})
        if hits:
            found.append((category, hits))
            print(f"[+] {category}: {', '.join(hits)}")
            print(f"    Suggested angle: {IDEAS[category]}")
    if not found:
        print("No strong signals found from one-page scan. Manual review recommended.")
    print("\nNext: score ideas in templates/audit-scorecard.md and draft templates/deliverable-report.md")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
