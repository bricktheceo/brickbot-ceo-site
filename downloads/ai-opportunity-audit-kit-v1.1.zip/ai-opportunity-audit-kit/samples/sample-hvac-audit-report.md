# Sample AI Opportunity Audit Report — HVAC Company

**Business:** Sample HVAC Co.  
**Website reviewed:** example.com  
**Prepared by:** BrickBot  
**Use case:** Demonstrates the paid deliverable a buyer can produce with this kit.

## Executive summary
The highest-value automation is usually not a complex chatbot. For a local HVAC company, the immediate money is in faster lead response, cleaner quote intake, and post-job review capture. These are low-risk workflows that can be tested without replacing existing dispatch or CRM tools.

## Top 3 opportunities

### 1. Missed-call text-back + lead triage
- **Current friction:** After-hours or busy-season calls can go unanswered.
- **Suggested automation:** Send an instant SMS asking service type, urgency, ZIP code, and preferred callback time.
- **Expected benefit:** More captured emergency/repair leads and fewer dead voicemails.
- **Difficulty:** Low/Medium
- **30-day metric:** Missed-call lead capture rate and booked appointments from SMS replies.

### 2. Quote intake form that routes by urgency
- **Current friction:** Generic contact forms do not separate emergency, replacement, maintenance, and warranty requests.
- **Suggested automation:** Add a structured intake form and route high-urgency jobs to phone/SMS while lower-urgency requests get calendar options.
- **Expected benefit:** Faster prioritization and less back-and-forth.
- **Difficulty:** Low
- **30-day metric:** Time-to-first-response and qualified quote requests.

### 3. Review request sequence after completed jobs
- **Current friction:** Happy customers forget unless prompted quickly.
- **Suggested automation:** Send a polite SMS/email review request 2–6 hours after job completion, with one follow-up.
- **Expected benefit:** More Google reviews and stronger local conversion.
- **Difficulty:** Low
- **30-day metric:** New reviews/month and review conversion rate.

## Scorecard
| Opportunity | Revenue impact | Time saved | Ease | Risk | Data readiness | Total |
|---|---:|---:|---:|---:|---:|---:|
| Missed-call text-back | 5 | 4 | 4 | 4 | 4 | 21 |
| Quote/booking intake | 4 | 4 | 5 | 4 | 4 | 21 |
| Review request automation | 4 | 3 | 5 | 5 | 4 | 21 |
| FAQ/chat handoff | 3 | 3 | 3 | 3 | 3 | 15 |

## Suggested pilot
Start with missed-call text-back for 14 days. Keep the scope narrow: only capture caller name, service need, urgency, ZIP code, and callback window. Review replies daily and compare against voicemail-only baseline.
