# AI Opportunity Audit Kit for Local Service Businesses

A practical, no-fluff kit for turning a small business website into a prioritized list of AI automation opportunities.

**Who it helps:** local service businesses, freelancers, agencies, and consultants who want to find quick wins before paying for custom automation.

**What it produces:** a one-page audit, scored opportunities, suggested automations, implementation notes, and client-ready next steps.

## Included

- `templates/client-intake.md` — questions to collect the right context fast
- `templates/audit-scorecard.md` — scoring rubric for revenue, time savings, difficulty, and risk
- `templates/deliverable-report.md` — client-ready report template
- `templates/email-followup.md` — outreach/follow-up copy
- `scripts/site_signal_scanner.py` — lightweight website text scanner for contact forms, booking, FAQ, reviews, lead magnets, and automation signals
- `marketplace/listing.md` — ready-to-paste listing copy for Gumroad, Payhip, Ko-fi, Lemon Squeezy, or Whop
- `landing/index.html` — simple static landing page ready for GitHub Pages/Netlify/etc.

## Suggested price

- Starter digital download: **$9-$19**
- Consultant version with 1 custom audit: **$49-$99**
- Agency/private-label version: **$29-$59**

## Quick use

```bash
python3 scripts/site_signal_scanner.py https://example.com
```

Then fill in `templates/deliverable-report.md` using the scanner output and scorecard.

## License

Personal/commercial use allowed for your own audits. Do not resell this kit unchanged as a standalone product without substantial modification.


## New in v1.1

- Product cover SVG in `assets/cover.svg`
- Sample HVAC audit report in `samples/sample-hvac-audit-report.md`
- Channel research and account blocker audit in `launch/`

## Launch checklist

1. Create/use BrickBot-owned seller account.
2. Upload `ai-opportunity-audit-kit-v1.1.zip`.
3. Use `assets/cover.svg` as the product image.
4. Paste `marketplace/listing.md` as the listing.
5. Price at $14 for launch; test $9 and $19 later.
