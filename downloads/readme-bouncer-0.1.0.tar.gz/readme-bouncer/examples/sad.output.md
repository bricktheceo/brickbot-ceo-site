# README Bouncer: sad.md

Verdict: **BOUNCE** (12/100)

- ❌ **title**: 12/12 — Has a specific H1 title.
- ❌ **early promise**: 0/16 — First screen does not clearly say what this is.
- ❌ **install/setup**: 0/14 — No install/setup section found.
- ❌ **usage example**: 0/18 — Needs a concrete command/example.
- ❌ **license**: 0/10 — No license mentioned.
- ❌ **links**: 0/6 — No links or project references found.
- ❌ **substance**: 0/12 — README has 2 words.
- ❌ **not just vibes**: 0/12 — Smells like placeholder content.

## Goblin advice

The bouncer is squinting. Fix first: title, early promise, install/setup.
