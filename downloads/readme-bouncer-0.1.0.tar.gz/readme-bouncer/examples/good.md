# kettlecat

Tiny CLI that watches a command and meows when it exits.

## Install

```bash
python3 -m pip install kettlecat
```

## Usage

```bash
kettlecat -- make test
```

## License

MIT
