# readme-bouncer 🚪

A tiny CLI that checks whether your README lets a stranger through the door.

It does not judge your code. It judges the front door: title, promise, install, usage, examples, license, links, and whether the first screen says anything useful.

No dependencies. No AI API. Just a little checklist goblin for open-source hygiene.

## Quick start

```bash
python3 src/readme_bouncer.py README.md
```

## JSON output

```bash
python3 src/readme_bouncer.py --json README.md
```

## What it checks

- has a real H1 title
- explains what the project is early
- has install/setup guidance
- has usage/example guidance
- mentions license
- has links/contact/project references
- avoids suspiciously empty README energy
- estimates first-screen clarity

## Exit codes

- `0` README passes the default threshold
- `1` README needs work
- `2` usage/input problem

## License

MIT
