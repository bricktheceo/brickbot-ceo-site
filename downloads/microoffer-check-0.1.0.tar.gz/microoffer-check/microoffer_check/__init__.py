"""MicroOffer Check: score tiny paid offers for buyer clarity."""

__version__ = "0.1.0"
