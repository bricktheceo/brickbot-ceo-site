import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional
from urllib.request import Request, urlopen


@dataclass(frozen=True)
class Check:
    key: str
    label: str
    weight: int
    patterns: tuple[str, ...]
    advice: str


CHECKS = (
    Check("audience", "Names a specific buyer/audience", 12, (r"for\s+([a-z0-9 -]+)", r"founders?", r"agenc(?:y|ies)", r"local\s+business", r"solo\s+dev"), "Say exactly who this is for."),
    Check("outcome", "Promises a concrete outcome", 14, (r"increase", r"reduce", r"save\s+\d+", r"find\s+\d+", r"fix", r"score", r"report", r"audit"), "Lead with the useful end result, not the format."),
    Check("scope", "Defines the deliverable/scope", 12, (r"you\s+get", r"includes", r"deliver", r"pdf", r"report", r"checklist", r"within\s+\d+", r"\d+\s*(?:page|point|minute|hour)"), "List what the buyer receives and how much."),
    Check("price", "Shows price or pricing path", 10, (r"\$\s?\d+", r"usd", r"price", r"paid", r"free", r"quote"), "Make the cost or next pricing step visible."),
    Check("cta", "Has a clear call to action", 14, (r"book", r"buy", r"order", r"request", r"email", r"start", r"get\s+(?:the|a|your)", r"send\s+me"), "Use one obvious next-action verb."),
    Check("reply_path", "Provides a reply/contact path", 10, (r"[\w.+-]+@[\w.-]+\.[a-z]{2,}", r"mailto:", r"contact", r"form", r"dm\s+me"), "Give buyers a way to reach you."),
    Check("trust", "Includes trust/risk reducer", 10, (r"sample", r"example", r"refund", r"no\s+spam", r"privacy", r"before\s+you\s+pay", r"fit", r"guarantee"), "Add a sample, fit check, privacy note, or guarantee."),
    Check("urgency", "Explains when to use it", 8, (r"when", r"if\s+you", r"before", r"launch", r"today", r"this\s+week"), "Tell the buyer when this is worth acting on."),
    Check("specificity", "Avoids vague marketing mush", 10, (r"\d+", r"\b(?:landing page|readme|checkout|homepage|offer|website)\b", r"\b(?:mini|audit|roast|scan|triage)\b"), "Swap generic benefits for concrete nouns and numbers."),
)

MUSH = (
    "revolutionary", "game-changing", "unlock your potential", "seamless", "leverage", "synergy",
    "world-class", "next-level", "supercharge", "innovative solution",
)


def read_source(source: str) -> str:
    if source == "-":
        return sys.stdin.read()
    if source.startswith(("http://", "https://")):
        req = Request(source, headers={"User-Agent": "microoffer-check/0.1"})
        with urlopen(req, timeout=15) as resp:
            data = resp.read(500_000)
        return data.decode("utf-8", errors="replace")
    return Path(source).read_text(encoding="utf-8")


def normalize(text: str) -> str:
    text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip().lower()


def analyze(text: str) -> dict:
    clean = normalize(text)
    hits = []
    misses = []
    score = 0
    for check in CHECKS:
        matched = any(re.search(p, clean, flags=re.I) for p in check.patterns)
        item = {"key": check.key, "label": check.label, "weight": check.weight, "advice": check.advice}
        if matched:
            score += check.weight
            hits.append(item)
        else:
            misses.append(item)

    mush_found = [phrase for phrase in MUSH if phrase in clean]
    penalty = min(12, 4 * len(mush_found))
    score = max(0, min(100, score - penalty))
    grade = "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 55 else "D" if score >= 40 else "F"
    return {"score": score, "grade": grade, "hits": hits, "misses": misses, "mush": mush_found, "penalty": penalty}


def format_report(result: dict, source: str) -> str:
    lines = [f"MicroOffer Check: {source}", f"Score: {result['score']}/100 ({result['grade']})", ""]
    if result["misses"]:
        lines.append("Fix next:")
        for miss in result["misses"][:5]:
            lines.append(f"- {miss['label']}: {miss['advice']}")
        lines.append("")
    if result["mush"]:
        lines.append("Vague words to replace:")
        lines.append("- " + ", ".join(result["mush"]))
        lines.append("")
    lines.append("Passed checks:")
    for hit in result["hits"]:
        lines.append(f"- {hit['label']}")
    return "\n".join(lines)


def main(argv: Optional[Iterable[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Score a tiny paid offer page for buyer clarity.")
    parser.add_argument("source", help="File path, URL, or '-' for stdin")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    parser.add_argument("--fail-under", type=int, default=None, help="Exit 1 if score is below this number")
    args = parser.parse_args(list(argv) if argv is not None else None)

    try:
        text = read_source(args.source)
    except Exception as exc:
        print(f"microoffer-check: could not read {args.source}: {exc}", file=sys.stderr)
        return 2

    result = analyze(text)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(format_report(result, args.source))
    if args.fail_under is not None and result["score"] < args.fail_under:
        return 1
    return 0
