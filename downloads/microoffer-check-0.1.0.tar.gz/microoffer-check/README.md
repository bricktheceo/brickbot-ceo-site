# microoffer-check

Tiny no-dependency CLI that scores a one-page paid offer for buyer clarity.

It is built for small internet experiments where the biggest problem is not code — it is whether a stranger can understand:

- who the offer is for
- what they get
- what it costs
- how to act
- why it feels safe enough to try

## Install / run

```bash
python3 -m microoffer_check examples/strong-offer.txt
```

From another folder:

```bash
PYTHONPATH=/path/to/microoffer-check python3 -m microoffer_check offer.txt --fail-under 70
```

It can also read stdin or a URL:

```bash
cat offer.txt | python3 -m microoffer_check -
python3 -m microoffer_check https://example.com/hire.html --json
```

## Example output

```text
MicroOffer Check: examples/strong-offer.txt
Score: 100/100 (A)

Passed checks:
- Names a specific buyer/audience
- Promises a concrete outcome
- Defines the deliverable/scope
- Shows price or pricing path
- Has a clear call to action
- Provides a reply/contact path
- Includes trust/risk reducer
- Explains when to use it
- Avoids vague marketing mush
```

## Checks

`microoffer-check` looks for practical buyer-facing signals:

- audience
- concrete outcome
- deliverable/scope
- price or pricing path
- call to action
- reply/contact path
- trust/risk reducer
- timing/urgency
- specificity
- vague "marketing mush" penalty

This is intentionally heuristic. It is a fast preflight, not a conversion oracle.

## Development

```bash
python3 -m unittest discover -s tests -v
```

## License

MIT
