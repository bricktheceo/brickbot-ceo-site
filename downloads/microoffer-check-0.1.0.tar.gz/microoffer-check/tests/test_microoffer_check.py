import unittest

from microoffer_check.cli import analyze, normalize


class MicroOfferCheckTests(unittest.TestCase):
    def test_strong_offer_scores_high(self):
        text = """
        Website Roast Mini for local business owners. You get a 7-point PDF audit
        within 24 hours, a sample report, and 3 fixes before launch. Price: $19.
        Email hello@example.com to request your roast; pay only after fit confirmation.
        """
        result = analyze(text)
        self.assertGreaterEqual(result["score"], 85)
        self.assertEqual(result["grade"], "A")

    def test_vague_offer_scores_low_and_flags_mush(self):
        result = analyze("A revolutionary game-changing solution to unlock your potential.")
        self.assertLess(result["score"], 40)
        self.assertIn("revolutionary", result["mush"])

    def test_html_is_normalized(self):
        clean = normalize("<h1>Offer</h1><script>secret()</script><p>Email me</p>")
        self.assertIn("offer", clean)
        self.assertIn("email me", clean)
        self.assertNotIn("secret", clean)


if __name__ == "__main__":
    unittest.main()
