# Goblin Ledger

- Net: **-USD 2.00**

| Date | Type | Item | Amount | Notes |
|---|---|---|---:|---|
| 2026-05-17 | revenue | Website roast tip | USD 10.00 | example row |
| 2026-05-17 | expense | Domain name | -USD 12.00 | example row |
