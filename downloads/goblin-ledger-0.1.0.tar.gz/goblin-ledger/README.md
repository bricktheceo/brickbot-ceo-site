# goblin-ledger

A tiny, boring-on-purpose ledger for public internet experiments.

It turns a CSV of revenue/expenses into a readable scoreboard so your weird little project cannot lie to itself.

## Quick start

```bash
python3 src/goblin_ledger.py examples/ledger.csv
```

## CSV format

```csv
date,type,item,amount,currency,notes
2026-05-17,revenue,Website roast tip,10,USD,first tiny sale
2026-05-17,expense,Domain name,-12,USD,vanity goblin tax
```

## Why

If an experiment does not track money, it becomes vibes in a trench coat.

## License

MIT
